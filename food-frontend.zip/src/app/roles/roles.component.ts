import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Roles } from '../roledetails/roledetails.component';
import { RolesDataService } from '../service/data/roles/roles-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  id: number;
  username: string;
  roleForm: FormGroup;
  role: Roles;
  submitted = false;
  constructor(private formBuilder: FormBuilder,
    private rolesService: RolesDataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.username = sessionStorage.getItem(AUTHENTICATED_USER);

    this.roleForm = this.formBuilder.group({
      rolename: ['', [Validators.required]],
      roledescription: ['', [Validators.required]]
    });

    if (this.id != -1) {
      this.rolesService.retrieveRole(this.username, this.id)
        .subscribe(
          data => {
            console.log(data);
            this.roleForm = this.formBuilder.group({
              rolename : [data.rolename, [Validators.required]],
              roledescription: [data.roledescription, [Validators.required]]
            });
          }
        );
    }
  }
  // convenience getter for easy access to form fields
  get f() { return this.roleForm.controls; }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.roleForm.invalid) {
      return;
    }
    if (this.id==-1) {
      this.rolesService.createRoles(this.username, this.roleForm.value)
        .subscribe(
          data => {
            console.log(data);
            this.router.navigate(['roles']);
          }
        );
    } else {
       this.rolesService.updateRoles(this.username, this.id, this.roleForm.value)
         .subscribe (
             data => {
               console.log(data);
               this.router.navigate(['roles']);
             }
           );
    }
  }
  exitPage() {
    this.router.navigate(['roles']);
  }
}
