import { TodoComponent } from './todo/todo.component';
import { RouteGuardService } from './service/route-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { ListTodosComponent } from './list-todos/list-todos.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ErrorComponent } from './error/error.component';
import { UsersComponent } from './users/users.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { RoledetailsComponent } from './roledetails/roledetails.component';
import { RolesComponent } from './roles/roles.component';
import { PagecreationComponent } from './pagecreation/pagecreation.component';
import { ManagerpagesComponent } from './managerpages/managerpages.component';
import { FoodComponent } from './food/food.component';
import { ListFoodComponent } from './list-food/list-food.component';

// welcome
const routes: Routes = [
  { path: '', component: LoginComponent  }, // canActivate, RouteGuardService
  { path: 'login', component: LoginComponent },
  { path: 'welcome/:name', component: WelcomeComponent, canActivate: [RouteGuardService]},
  { path: 'todos', component: ListTodosComponent, canActivate: [RouteGuardService] },
  
  { path: 'logout', component: LogoutComponent, canActivate: [RouteGuardService] },
  { path: 'todos/:id', component: TodoComponent, canActivate: [RouteGuardService] },
  { path: 'users', component: UserdetailsComponent, canActivate: [RouteGuardService] },
  { path: 'users/:id', component: UsersComponent, canActivate: [RouteGuardService] },
  { path: 'roles', component: RoledetailsComponent, canActivate: [RouteGuardService] },
  { path: 'roles/:id', component: RolesComponent, canActivate: [RouteGuardService] },
  { path: 'pagecreation', component: ManagerpagesComponent, canActivate: [RouteGuardService] },
  { path: 'pagecreation/:id', component: PagecreationComponent, canActivate: [RouteGuardService] },
  {path: 'foodlist', component: ListFoodComponent, canActivate: [RouteGuardService] },
  { path: 'food/', component: FoodComponent, canActivate: [RouteGuardService] },
  { path: 'food/:id', component: FoodComponent, canActivate: [RouteGuardService] },


  { path: '**', component: ErrorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
