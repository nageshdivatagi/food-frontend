import { Component, OnInit } from '@angular/core';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';
import { Router } from '@angular/router';
import { FoodDataService } from '../service/data/food-data.service';


export class Food {
  constructor(
    /*
    private Long id;
    private String hotel;
    private String foodName;
    private String foodType;
    private String foodDescription;
    private double prize;
    private boolean isAvailable;*/

    public id: number,
    public hotel: string,
    public foodName: string,
    public foodType: string,
    public foodDescription: string,
    public prize: string,
    public available: boolean
  ) { }
}

export class Order {
  constructor(
    /*
    private Long id;
	private String customername;*/

    public id: number,
    public customername: string
  ) { }
}

@Component({
  selector: 'app-list-food',
  templateUrl: './list-food.component.html',
  styleUrls: ['./list-food.component.css']
})

export class ListFoodComponent implements OnInit {
 
  foods: Food[];
  username: string;
  message: string;
  searchname: string;
  orders: Order[];
  constructor(
    private foodDataService : FoodDataService,
    private router: Router
  ) { }

  ngOnInit() {

    this.username = sessionStorage.getItem(AUTHENTICATED_USER);
    console.log('Hi i am ' + this.username);
   
    this.refreshFoods();
  }

  refreshFoods() {
    this.foodDataService.retrieveAllFoods(this.username).subscribe(
      response => {
        console.log(response);
        this.foods = response;
      }
    );
  }
  searchRestorent(searchname){
    this.foodDataService.retrieveFoodByHotel(this.username, searchname).subscribe(
      response => {
        console.log(response);
        this.foods = response;
      }
    );
  }
  deleteFood(id) {
    this.foodDataService.deleteFood(this.username, id).subscribe (
      response => {
        console.log(response);
        this.message = `Delete of Todo ${id} Successful!`;
        this.refreshFoods();
      }
    );
  }

  foodOrder(id) {
    this.foodDataService.foodOrder(this.username, id,this.orders).subscribe (
      response => {
        console.log(response);
        this.message = `Order Requested Id: ${id} Successful!`;
        this.refreshFoods();
      }
    );
  }


  updateFood(id) {
    this.router.navigate(['food', id]);
  }

  
  orderFood(id) {
    this.router.navigate(['food', id]);
  }

  addFood() {
    this.router.navigate(['food', -1]);
  }
}
