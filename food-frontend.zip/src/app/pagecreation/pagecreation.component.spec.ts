import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagecreationComponent } from './pagecreation.component';

describe('PagecreationComponent', () => {
  let component: PagecreationComponent;
  let fixture: ComponentFixture<PagecreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagecreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagecreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
