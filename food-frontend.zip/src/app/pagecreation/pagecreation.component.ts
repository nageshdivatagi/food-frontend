import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagecreation',
  templateUrl: './pagecreation.component.html',
  styleUrls: ['./pagecreation.component.css']
})
export class PagecreationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
