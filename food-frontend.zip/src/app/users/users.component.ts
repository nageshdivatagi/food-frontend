import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MustMatch } from '../helper/must.validater';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UserDataService } from '../service/data/user-data.service';


export class User {
  constructor(
    public userId: number,
    public username: string,
    public firstname: string,
    public lastname: string,
    public emailId: string,
    public password: string,
    public mobileNo: string,
    public lastLogged: Date,
    public genderId: number,
    public roleId: number,
    public tempBlock: boolean,
    public tempblockDate: Date,
    public block: boolean,
    public blockedDate: Date,
    public passwordChangeFlag: Number,
    public passwordChangeDate: Date,
    public addUser: Number,
    public lastLoggedIn: Date,
    public addedDate: Date
  ) { }
}
export class Gender {
  id: Number;
  name: String;
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  id: number;
  username: string;
  userForm: FormGroup;
  user: User;
  submitted = false;
  genders: Gender[];
  constructor(private formBuilder: FormBuilder,
    private userService: UserDataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.username = sessionStorage.getItem(AUTHENTICATED_USER);

    this.genders = [
      { name: "Male", id: 1 },
      { name: "Female", id: 2 },
      { name: "Other", id: 3 }
    ];
    this.userForm = this.formBuilder.group({
      firstname: ['', [Validators.required]],
      lastname: ['', [Validators.required]],
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      mobileNo: ['', [Validators.required, Validators.minLength(10)]],
      username: ['', [Validators.required]],
      genderId: ['', [Validators.required]],
      roleId: ['', [Validators.required]],
      block: [false]
    }, {
        validator: MustMatch('password', 'confirmPassword')
      });

    if (this.id != -1) {
      this.userService.retrieveUser(this.username, this.id)
        .subscribe(
          data => {
            console.log(data);
            this.userForm = this.formBuilder.group({
              firstname: [data.firstname, [Validators.required]],
              lastname: [data.lastname, [Validators.required]],
              emailId: [data.emailId, [Validators.required, Validators.email]],
              password: ['', [Validators.required, Validators.minLength(6)]],
              confirmPassword: ['', [Validators.required]],
              mobileNo: [data.mobileNo, [Validators.required, Validators.minLength(10)]],
              username: [data.username, [Validators.required]],
              genderId: [data.genderId, [Validators.required]],
              roleId: [data.roleId, [Validators.required]],
              block: [data.block]
            });
          }
        );
    }
  }
  // convenience getter for easy access to form fields
  get f() { return this.userForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.userForm.invalid) {
      return;
    }

   // alert('SUCCESS!! :-)\n\n' + this.userForm.value);
    // console.log(this.user);

    if (this.id==-1) {
      this.userService.createUser(this.username, this.userForm.value)
        .subscribe(
          data => {
            console.log(data);
            this.router.navigate(['users']);
          }
        );
    } else {
       this.userService.updateUser(this.username, this.id, this.userForm.value)
         .subscribe (
             data => {
               console.log(data);
               this.router.navigate(['users']);
             }
           );
    }
    //
  }
  exitPage() {
    this.router.navigate(['users']);
  }
}
