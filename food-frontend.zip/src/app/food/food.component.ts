import { Component, OnInit } from '@angular/core';
import { Food } from '../list-food/list-food.component';
import { FoodDataService } from '../service/data/food-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
  id:number;
  username:string;
  food: Food;
  foodForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private foodDataService: FoodDataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.username = sessionStorage.getItem(AUTHENTICATED_USER);
    
    this.food = new Food(this.id,'','','','','',false);
    this.foodForm = this.formBuilder.group({
      rolename: ['', [Validators.required]],
      roledescription: ['', [Validators.required]]
    });
    if (this.id!=-1) {
      this.foodDataService.retrieveFood(this.username, this.id)
          .subscribe (
            data => this.food = data
          );
    }
  }
  saveTodo() {
    if(this.id == -1) { 
      console.log(this.username);
      this.foodDataService.createFood(this.username, this.food)
          .subscribe (
            data => {
              console.log(data)
              this.router.navigate(['foodlist'])
            }
          )
    } else {
      this.foodDataService.updateFood(this.username, this.id, this.food)
          .subscribe (
            data => {
              console.log(data)
              this.router.navigate(['foodlist'])
            }
          )
    }
  }

}
