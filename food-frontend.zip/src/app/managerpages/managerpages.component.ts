import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managerpages',
  templateUrl: './managerpages.component.html',
  styleUrls: ['./managerpages.component.css']
})
export class ManagerpagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
