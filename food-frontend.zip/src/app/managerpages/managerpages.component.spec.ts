import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerpagesComponent } from './managerpages.component';

describe('ManagerpagesComponent', () => {
  let component: ManagerpagesComponent;
  let fixture: ComponentFixture<ManagerpagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerpagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerpagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
