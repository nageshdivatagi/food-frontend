import { Injectable } from '@angular/core';
import { AUTHENTICATED_USER, TOKEN } from './basic-authentication.service';
import { TodoDataService } from './data/todo-data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthenticationService {

  constructor(
    private todoService: TodoDataService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  authenticate(username, password) {
    // console.log('before ' + this.isUserLoggedIn());
    if (username === "in28minutes" && password === 'dummy') {
      sessionStorage.setItem('authenticaterUser', username);
      // console.log('after ' + this.isUserLoggedIn());
      return true;
    }
    return false;
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('authenticaterUser');
    return !(user === null);
  }

  logout() {
    console.log('Hi Nagesh.D');

    this.todoService.sessionLogOut(sessionStorage.getItem(AUTHENTICATED_USER))
      .subscribe(
        data => {
          this.router.navigate(['login']);
        }
      );
    sessionStorage.removeItem(AUTHENTICATED_USER);
    sessionStorage.removeItem(TOKEN);
  }

}
