import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Roles } from 'src/app/roledetails/roledetails.component';
import { TODO_JPA_API_URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class RolesDataService {

  constructor(
    private http: HttpClient
  ) { }

  retrieveAllRoles(username) {
    return this.http.get<Roles[]>(`${TODO_JPA_API_URL}/users/${username}/roles`);
    // console.log("Execute Hello World Bean Service")
  }

  deleteRole(username, id) {
    return this.http.delete(`${TODO_JPA_API_URL}/users/${username}/roles/${id}`);
  }

  retrieveRole(username, id) {
    return this.http.get<Roles>(`${TODO_JPA_API_URL}/users/${username}/roles/${id}`);
  }

  updateRoles(username, id, roles) {
    return this.http.put(
          `${TODO_JPA_API_URL}/users/${username}/roles/${id}`
                , roles);
  }

  createRoles(username, roles) {
    return this.http.post(
              `${TODO_JPA_API_URL}/users/${username}/roles`
                , roles);
  }

}
