import { TestBed } from '@angular/core/testing';

import { RolesDataService } from './roles-data.service';

describe('RolesDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RolesDataService = TestBed.get(RolesDataService);
    expect(service).toBeTruthy();
  });
});
