import { TODO_JPA_API_URL } from './../../app.constants';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from 'src/app/users/users.component';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {

  constructor(private http: HttpClient) { }

  retrieveAllUsers(username) {
    return this.http.get<User[]>(`${TODO_JPA_API_URL}/users/${username}/user`);
    // console.log("Execute Hello World Bean Service")
  }

  deleteUser(username, id) {
    return this.http.delete(`${TODO_JPA_API_URL}/users/${username}/user/${id}`);
  }

  retrieveUser(username, id) {
    return this.http.get<User>(`${TODO_JPA_API_URL}/users/${username}/user/${id}`);
  }

  updateUser(username, id, user) {
    return this.http.put(
          `${TODO_JPA_API_URL}/users/${username}/user/${id}`
                , user);
  }

  createUser(username, user) {
    return this.http.post(
              `${TODO_JPA_API_URL}/users/${username}/user`
                , user);
  }

}
