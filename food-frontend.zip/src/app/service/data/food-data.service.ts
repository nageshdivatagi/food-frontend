import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Food } from 'src/app/list-food/list-food.component';
import { TODO_JPA_API_URL, API_URL } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class FoodDataService {

  constructor(
    private http: HttpClient
  ) { }
  
  retrieveAllFoods(username) {
    return this.http.get<Food[]>(`${TODO_JPA_API_URL}/users/${username}/food`);
  }
  retrieveFoodByHotel(username,hotelname) {
    return this.http.get<Food[]>(`${TODO_JPA_API_URL}/users/${username}/getfoodlist/${hotelname}`);
  }

  deleteFood(username, id) {
    return this.http.delete(`${TODO_JPA_API_URL}/users/${username}/food/${id}`);
  }

  retrieveFood(username, id) {
    return this.http.get<Food>(`${TODO_JPA_API_URL}/users/${username}/food/${id}`);
  }

  updateFood(username, id, food) {
    return this.http.put(
          `${TODO_JPA_API_URL}/users/${username}/food/${id}`
                , food);
  }

  foodOrder(username, id, order) {
    return this.http.post(
          `${TODO_JPA_API_URL}/users/${username}/order/${id}`
                , order);
  }
  createFood(username, food) {
    return this.http.post(
              `${TODO_JPA_API_URL}/users/${username}/food`
                , food);
  }

  sessionLogOut(username) {
    return this.http.get(`${API_URL}/users/${username}/logout`);
  }


}
