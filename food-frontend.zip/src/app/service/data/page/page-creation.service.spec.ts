import { TestBed } from '@angular/core/testing';

import { PageCreationService } from './page-creation.service';

describe('PageCreationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PageCreationService = TestBed.get(PageCreationService);
    expect(service).toBeTruthy();
  });
});
