export class Globlevariables {
    constructor(
        public id: number,
        public username: string,
        public password: string,
        public jwtToken: string,
        public role: string
      ) { }
      
}