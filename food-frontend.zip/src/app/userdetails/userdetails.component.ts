import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../users/users.component';
import { UserDataService } from '../service/data/user-data.service';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {

  id: number;
  username: string;
  user: User[];
  message: string;

  constructor(
    private userService: UserDataService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.username = sessionStorage.getItem(AUTHENTICATED_USER);
    console.log('Hi i am ' + this.username);
    this.refreshUsers();
  }
  refreshUsers() {
    this.userService.retrieveAllUsers(this.username).subscribe(
      response => {
        console.log(response);
        this.user = response;
      }
    );
  }


  createNewUser() {
    this.router.navigate(['users', -1]);
  }
  updateUser(id) {
    this.router.navigate(['users', id]);
  }
  deleteUser(id) {
    this.userService.deleteUser(this.username, id).subscribe (
      response => {
        console.log(response);
        this.message = `Delete of Todo ${id} Successful!`;
        this.refreshUsers();
      }
    );
  }
}
