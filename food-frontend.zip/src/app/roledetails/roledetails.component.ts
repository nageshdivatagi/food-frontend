import { Component, OnInit } from '@angular/core';
import { RolesDataService } from '../service/data/roles/roles-data.service';
import { Router } from '@angular/router';
import { AUTHENTICATED_USER } from '../service/basic-authentication.service';

export class Roles {
  constructor(
    public roleid: number,
    public rolename: string,
    public roledescription: string
  ) { }
}

@Component({
  selector: 'app-roledetails',
  templateUrl: './roledetails.component.html',
  styleUrls: ['./roledetails.component.css']
})
export class RoledetailsComponent implements OnInit {
 
  message: string;
  roles: Roles[];
  username: string;
  searchText;
  constructor(private rolesService: RolesDataService,
    private router: Router) { }

  ngOnInit() {
    this.username = sessionStorage.getItem(AUTHENTICATED_USER);
    this.refreshRoles();
  }

  refreshRoles() {
    this.rolesService.retrieveAllRoles(this.username).subscribe(
      response => {
        console.log(response);
        this.roles = response;
      }
    );
  }


  createNewRole() {
    this.router.navigate(['roles', -1]);
  }
  updateRole(id) {
    this.router.navigate(['roles', id]);
  }
  deleteRole(id) {
    this.rolesService.deleteRole(this.username, id).subscribe (
      response => {
        console.log(response);
        this.message = `Delete of Todo ${id} Successful!`;
        this.refreshRoles();
      }
    );
  }
  

}
